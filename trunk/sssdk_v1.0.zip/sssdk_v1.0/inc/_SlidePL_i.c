

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Sat Apr 11 17:41:06 2009
 */
/* Compiler settings for _SlidePL.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#if !defined(_M_IA64) && !defined(_M_AMD64)


#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_ISlideImage,0x69F52DC4,0x2C0D,0x493F,0xBA,0x07,0xB7,0x7A,0xAD,0xC0,0x49,0x53);


MIDL_DEFINE_GUID(IID, IID_ISlideEffect,0x8B8A6A6D,0xC21E,0x4BCB,0x8D,0xD4,0xFB,0x14,0x69,0xDE,0xF2,0xD4);


MIDL_DEFINE_GUID(IID, IID_ISlideTransition,0x7F38E55D,0x78CA,0x4434,0xB9,0x75,0x75,0x06,0x84,0x1A,0x4A,0x6C);


MIDL_DEFINE_GUID(IID, IID_ISlideFactory,0x04196464,0x735C,0x4F51,0xAF,0xE0,0x0C,0xA3,0x9F,0x9D,0x22,0x5D);


MIDL_DEFINE_GUID(IID, LIBID_SlidePL,0x44E51716,0x6049,0x4C76,0x97,0xCE,0x3D,0x45,0x42,0x54,0x87,0xCA);


MIDL_DEFINE_GUID(CLSID, CLSID_CSlideImage,0x1AE93581,0xD93B,0x460F,0xA5,0xC8,0xAC,0xB8,0x4E,0xFD,0xEE,0xFF);


MIDL_DEFINE_GUID(CLSID, CLSID_CSlideEffect,0x94292858,0xFA59,0x4A84,0x91,0xE9,0x5E,0xCE,0xA0,0x3D,0xAA,0xFC);


MIDL_DEFINE_GUID(CLSID, CLSID_CSlideTransition,0x10949562,0xC891,0x4275,0x83,0x11,0x67,0xB4,0x53,0xBD,0x97,0xD5);


MIDL_DEFINE_GUID(CLSID, CLSID_CSlideFactory,0xADD76CEB,0x4B19,0x4E92,0x92,0x8E,0x46,0xAD,0x08,0x46,0x75,0x5F);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



#endif /* !defined(_M_IA64) && !defined(_M_AMD64)*/

