#include "StdAfx.h"
#include "resource.h"
#include "AboutDlg.h"

LRESULT CAboutDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	m_Link.Subclass(GetDlgItem(IDC_STATIC_GETFULL));
	CenterWindow(GetParent());
	
	return TRUE;
}

LRESULT CAboutDlg::OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	m_Link.UnSubclass();
	EndDialog(wID);
	return 0;
}

