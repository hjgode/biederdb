//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_LIST2                       1002
#define IDC_LIST_EFFECTS                1002
#define IDC_BUTTON_A                    1003
#define IDC_BUTTON_B                    1004
#define IDC_SLIDER_PROGRESS             1005
#define IDC_EDIT_DURATION               1006
#define IDC_SPIN_DURATION               1007
#define IDC_BUTTON_PLAY                 1008
#define IDC_BUTTON_PAUSE                1009
#define IDC_RADIO_EFFECT                1010
#define IDC_RADIO_TRANSITION            1011
#define IDC_NAME                        1012
#define IDC_DESCRIPTION                 1013
#define IDC_COMPANY                     1014
#define IDC_STATIC_GETFULL              1016
#define IDC_SLIDER1                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
