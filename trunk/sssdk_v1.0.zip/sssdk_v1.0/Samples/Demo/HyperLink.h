#pragma once

#include <string>

class CHyperLink
{
public:
	CHyperLink(void);
	virtual ~CHyperLink(void);
	BOOL Subclass(HWND);
	BOOL UnSubclass();
	
	static LRESULT CALLBACK LinkProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

private:
	BOOL GotoURL();

private:
	WNDPROC				m_ProcOrigin;
	HFONT				m_Font;
	HBRUSH				m_BackGround;
	HWND				m_hWnd;
	std::wstring		m_Link;
	std::wstring		m_Caption;
};
