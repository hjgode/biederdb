

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 6.00.0361 */
/* at Sat Apr 11 17:41:06 2009
 */
/* Compiler settings for _SlidePL.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 475
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef ___SlidePL_h__
#define ___SlidePL_h__

#if defined(_MSC_VER) && (_MSC_VER >= 1020)
#pragma once
#endif

/* Forward Declarations */ 

#ifndef __ISlideImage_FWD_DEFINED__
#define __ISlideImage_FWD_DEFINED__
typedef interface ISlideImage ISlideImage;
#endif 	/* __ISlideImage_FWD_DEFINED__ */


#ifndef __ISlideEffect_FWD_DEFINED__
#define __ISlideEffect_FWD_DEFINED__
typedef interface ISlideEffect ISlideEffect;
#endif 	/* __ISlideEffect_FWD_DEFINED__ */


#ifndef __ISlideTransition_FWD_DEFINED__
#define __ISlideTransition_FWD_DEFINED__
typedef interface ISlideTransition ISlideTransition;
#endif 	/* __ISlideTransition_FWD_DEFINED__ */


#ifndef __ISlideFactory_FWD_DEFINED__
#define __ISlideFactory_FWD_DEFINED__
typedef interface ISlideFactory ISlideFactory;
#endif 	/* __ISlideFactory_FWD_DEFINED__ */


#ifndef __CSlideImage_FWD_DEFINED__
#define __CSlideImage_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSlideImage CSlideImage;
#else
typedef struct CSlideImage CSlideImage;
#endif /* __cplusplus */

#endif 	/* __CSlideImage_FWD_DEFINED__ */


#ifndef __CSlideEffect_FWD_DEFINED__
#define __CSlideEffect_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSlideEffect CSlideEffect;
#else
typedef struct CSlideEffect CSlideEffect;
#endif /* __cplusplus */

#endif 	/* __CSlideEffect_FWD_DEFINED__ */


#ifndef __CSlideTransition_FWD_DEFINED__
#define __CSlideTransition_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSlideTransition CSlideTransition;
#else
typedef struct CSlideTransition CSlideTransition;
#endif /* __cplusplus */

#endif 	/* __CSlideTransition_FWD_DEFINED__ */


#ifndef __CSlideFactory_FWD_DEFINED__
#define __CSlideFactory_FWD_DEFINED__

#ifdef __cplusplus
typedef class CSlideFactory CSlideFactory;
#else
typedef struct CSlideFactory CSlideFactory;
#endif /* __cplusplus */

#endif 	/* __CSlideFactory_FWD_DEFINED__ */


/* header files for imported files */
#include "prsht.h"
#include "mshtml.h"
#include "mshtmhst.h"
#include "exdisp.h"
#include "objsafe.h"

#ifdef __cplusplus
extern "C"{
#endif 

void * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void * ); 

#ifndef __ISlideImage_INTERFACE_DEFINED__
#define __ISlideImage_INTERFACE_DEFINED__

/* interface ISlideImage */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISlideImage;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("69F52DC4-2C0D-493F-BA07-B77AADC04953")
    ISlideImage : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IsReady( 
            /* [retval][out] */ LONG *lReady) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetWidth( 
            /* [retval][out] */ LONG *lWidth) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetHeight( 
            /* [retval][out] */ LONG *lHeight) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPitch( 
            /* [retval][out] */ LONG *lPitch) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetSize( 
            /* [in] */ LONG lWidth,
            /* [in] */ LONG lHeight) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetBits( 
            /* [in] */ BYTE *Bits,
            /* [in] */ LONG lPitch) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SaveBitmap( 
            /* [in] */ BSTR __MIDL_0020) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadBits( 
            /* [in] */ BYTE *lBits,
            /* [in] */ LONGLONG lCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadFile( 
            /* [in] */ BSTR Filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE LoadStream( 
            /* [in] */ IStream *pStream) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Attach( 
            /* [in] */ LONG lWidth,
            /* [in] */ LONG lHeight,
            /* [in] */ LONG lPitch,
            /* [in] */ BYTE *lBits) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Fill( 
            /* [in] */ LONG lAlpha,
            /* [in] */ LONG lRed,
            /* [in] */ LONG lGreen,
            /* [in] */ LONG lBlue) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CopyFrom( 
            /* [in] */ ISlideImage *pPicture) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ResizeTo( 
            /* [in] */ ISlideImage *pPicture,
            /* [in] */ LONG lInterpolation) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Rotate( 
            /* [in] */ ISlideImage *pPicture,
            /* [in] */ LONG lAngle) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISlideImageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISlideImage * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISlideImage * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISlideImage * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISlideImage * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISlideImage * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISlideImage * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISlideImage * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *IsReady )( 
            ISlideImage * This,
            /* [retval][out] */ LONG *lReady);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetWidth )( 
            ISlideImage * This,
            /* [retval][out] */ LONG *lWidth);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetHeight )( 
            ISlideImage * This,
            /* [retval][out] */ LONG *lHeight);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetPitch )( 
            ISlideImage * This,
            /* [retval][out] */ LONG *lPitch);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetSize )( 
            ISlideImage * This,
            /* [in] */ LONG lWidth,
            /* [in] */ LONG lHeight);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetBits )( 
            ISlideImage * This,
            /* [in] */ BYTE *Bits,
            /* [in] */ LONG lPitch);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SaveBitmap )( 
            ISlideImage * This,
            /* [in] */ BSTR __MIDL_0020);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *LoadBits )( 
            ISlideImage * This,
            /* [in] */ BYTE *lBits,
            /* [in] */ LONGLONG lCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *LoadFile )( 
            ISlideImage * This,
            /* [in] */ BSTR Filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *LoadStream )( 
            ISlideImage * This,
            /* [in] */ IStream *pStream);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Attach )( 
            ISlideImage * This,
            /* [in] */ LONG lWidth,
            /* [in] */ LONG lHeight,
            /* [in] */ LONG lPitch,
            /* [in] */ BYTE *lBits);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Fill )( 
            ISlideImage * This,
            /* [in] */ LONG lAlpha,
            /* [in] */ LONG lRed,
            /* [in] */ LONG lGreen,
            /* [in] */ LONG lBlue);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CopyFrom )( 
            ISlideImage * This,
            /* [in] */ ISlideImage *pPicture);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *ResizeTo )( 
            ISlideImage * This,
            /* [in] */ ISlideImage *pPicture,
            /* [in] */ LONG lInterpolation);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *Rotate )( 
            ISlideImage * This,
            /* [in] */ ISlideImage *pPicture,
            /* [in] */ LONG lAngle);
        
        END_INTERFACE
    } ISlideImageVtbl;

    interface ISlideImage
    {
        CONST_VTBL struct ISlideImageVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISlideImage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISlideImage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISlideImage_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISlideImage_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISlideImage_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISlideImage_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISlideImage_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISlideImage_IsReady(This,lReady)	\
    (This)->lpVtbl -> IsReady(This,lReady)

#define ISlideImage_GetWidth(This,lWidth)	\
    (This)->lpVtbl -> GetWidth(This,lWidth)

#define ISlideImage_GetHeight(This,lHeight)	\
    (This)->lpVtbl -> GetHeight(This,lHeight)

#define ISlideImage_GetPitch(This,lPitch)	\
    (This)->lpVtbl -> GetPitch(This,lPitch)

#define ISlideImage_SetSize(This,lWidth,lHeight)	\
    (This)->lpVtbl -> SetSize(This,lWidth,lHeight)

#define ISlideImage_GetBits(This,Bits,lPitch)	\
    (This)->lpVtbl -> GetBits(This,Bits,lPitch)

#define ISlideImage_SaveBitmap(This,__MIDL_0020)	\
    (This)->lpVtbl -> SaveBitmap(This,__MIDL_0020)

#define ISlideImage_LoadBits(This,lBits,lCount)	\
    (This)->lpVtbl -> LoadBits(This,lBits,lCount)

#define ISlideImage_LoadFile(This,Filename)	\
    (This)->lpVtbl -> LoadFile(This,Filename)

#define ISlideImage_LoadStream(This,pStream)	\
    (This)->lpVtbl -> LoadStream(This,pStream)

#define ISlideImage_Attach(This,lWidth,lHeight,lPitch,lBits)	\
    (This)->lpVtbl -> Attach(This,lWidth,lHeight,lPitch,lBits)

#define ISlideImage_Fill(This,lAlpha,lRed,lGreen,lBlue)	\
    (This)->lpVtbl -> Fill(This,lAlpha,lRed,lGreen,lBlue)

#define ISlideImage_CopyFrom(This,pPicture)	\
    (This)->lpVtbl -> CopyFrom(This,pPicture)

#define ISlideImage_ResizeTo(This,pPicture,lInterpolation)	\
    (This)->lpVtbl -> ResizeTo(This,pPicture,lInterpolation)

#define ISlideImage_Rotate(This,pPicture,lAngle)	\
    (This)->lpVtbl -> Rotate(This,pPicture,lAngle)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_IsReady_Proxy( 
    ISlideImage * This,
    /* [retval][out] */ LONG *lReady);


void __RPC_STUB ISlideImage_IsReady_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_GetWidth_Proxy( 
    ISlideImage * This,
    /* [retval][out] */ LONG *lWidth);


void __RPC_STUB ISlideImage_GetWidth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_GetHeight_Proxy( 
    ISlideImage * This,
    /* [retval][out] */ LONG *lHeight);


void __RPC_STUB ISlideImage_GetHeight_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_GetPitch_Proxy( 
    ISlideImage * This,
    /* [retval][out] */ LONG *lPitch);


void __RPC_STUB ISlideImage_GetPitch_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_SetSize_Proxy( 
    ISlideImage * This,
    /* [in] */ LONG lWidth,
    /* [in] */ LONG lHeight);


void __RPC_STUB ISlideImage_SetSize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_GetBits_Proxy( 
    ISlideImage * This,
    /* [in] */ BYTE *Bits,
    /* [in] */ LONG lPitch);


void __RPC_STUB ISlideImage_GetBits_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_SaveBitmap_Proxy( 
    ISlideImage * This,
    /* [in] */ BSTR __MIDL_0020);


void __RPC_STUB ISlideImage_SaveBitmap_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_LoadBits_Proxy( 
    ISlideImage * This,
    /* [in] */ BYTE *lBits,
    /* [in] */ LONGLONG lCount);


void __RPC_STUB ISlideImage_LoadBits_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_LoadFile_Proxy( 
    ISlideImage * This,
    /* [in] */ BSTR Filename);


void __RPC_STUB ISlideImage_LoadFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_LoadStream_Proxy( 
    ISlideImage * This,
    /* [in] */ IStream *pStream);


void __RPC_STUB ISlideImage_LoadStream_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_Attach_Proxy( 
    ISlideImage * This,
    /* [in] */ LONG lWidth,
    /* [in] */ LONG lHeight,
    /* [in] */ LONG lPitch,
    /* [in] */ BYTE *lBits);


void __RPC_STUB ISlideImage_Attach_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_Fill_Proxy( 
    ISlideImage * This,
    /* [in] */ LONG lAlpha,
    /* [in] */ LONG lRed,
    /* [in] */ LONG lGreen,
    /* [in] */ LONG lBlue);


void __RPC_STUB ISlideImage_Fill_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_CopyFrom_Proxy( 
    ISlideImage * This,
    /* [in] */ ISlideImage *pPicture);


void __RPC_STUB ISlideImage_CopyFrom_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_ResizeTo_Proxy( 
    ISlideImage * This,
    /* [in] */ ISlideImage *pPicture,
    /* [in] */ LONG lInterpolation);


void __RPC_STUB ISlideImage_ResizeTo_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideImage_Rotate_Proxy( 
    ISlideImage * This,
    /* [in] */ ISlideImage *pPicture,
    /* [in] */ LONG lAngle);


void __RPC_STUB ISlideImage_Rotate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISlideImage_INTERFACE_DEFINED__ */


#ifndef __ISlideEffect_INTERFACE_DEFINED__
#define __ISlideEffect_INTERFACE_DEFINED__

/* interface ISlideEffect */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISlideEffect;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8B8A6A6D-C21E-4BCB-8DD4-FB1469DEF2D4")
    ISlideEffect : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetID( 
            /* [retval][out] */ LONG *lID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetName( 
            /* [retval][out] */ BSTR *pName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDescription( 
            /* [retval][out] */ BSTR *pDescription) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetFilename( 
            /* [retval][out] */ BSTR *pFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DoEffect( 
            /* [in] */ ISlideImage *pPicC,
            /* [in] */ ISlideImage *pPicA,
            /* [in] */ LONG lPercent,
            /* [in] */ LONGLONG lParam) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISlideEffectVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISlideEffect * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISlideEffect * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISlideEffect * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISlideEffect * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISlideEffect * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISlideEffect * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISlideEffect * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetID )( 
            ISlideEffect * This,
            /* [retval][out] */ LONG *lID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetName )( 
            ISlideEffect * This,
            /* [retval][out] */ BSTR *pName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetDescription )( 
            ISlideEffect * This,
            /* [retval][out] */ BSTR *pDescription);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetFilename )( 
            ISlideEffect * This,
            /* [retval][out] */ BSTR *pFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DoEffect )( 
            ISlideEffect * This,
            /* [in] */ ISlideImage *pPicC,
            /* [in] */ ISlideImage *pPicA,
            /* [in] */ LONG lPercent,
            /* [in] */ LONGLONG lParam);
        
        END_INTERFACE
    } ISlideEffectVtbl;

    interface ISlideEffect
    {
        CONST_VTBL struct ISlideEffectVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISlideEffect_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISlideEffect_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISlideEffect_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISlideEffect_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISlideEffect_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISlideEffect_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISlideEffect_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISlideEffect_GetID(This,lID)	\
    (This)->lpVtbl -> GetID(This,lID)

#define ISlideEffect_GetName(This,pName)	\
    (This)->lpVtbl -> GetName(This,pName)

#define ISlideEffect_GetDescription(This,pDescription)	\
    (This)->lpVtbl -> GetDescription(This,pDescription)

#define ISlideEffect_GetFilename(This,pFilename)	\
    (This)->lpVtbl -> GetFilename(This,pFilename)

#define ISlideEffect_DoEffect(This,pPicC,pPicA,lPercent,lParam)	\
    (This)->lpVtbl -> DoEffect(This,pPicC,pPicA,lPercent,lParam)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideEffect_GetID_Proxy( 
    ISlideEffect * This,
    /* [retval][out] */ LONG *lID);


void __RPC_STUB ISlideEffect_GetID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideEffect_GetName_Proxy( 
    ISlideEffect * This,
    /* [retval][out] */ BSTR *pName);


void __RPC_STUB ISlideEffect_GetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideEffect_GetDescription_Proxy( 
    ISlideEffect * This,
    /* [retval][out] */ BSTR *pDescription);


void __RPC_STUB ISlideEffect_GetDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideEffect_GetFilename_Proxy( 
    ISlideEffect * This,
    /* [retval][out] */ BSTR *pFilename);


void __RPC_STUB ISlideEffect_GetFilename_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideEffect_DoEffect_Proxy( 
    ISlideEffect * This,
    /* [in] */ ISlideImage *pPicC,
    /* [in] */ ISlideImage *pPicA,
    /* [in] */ LONG lPercent,
    /* [in] */ LONGLONG lParam);


void __RPC_STUB ISlideEffect_DoEffect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISlideEffect_INTERFACE_DEFINED__ */


#ifndef __ISlideTransition_INTERFACE_DEFINED__
#define __ISlideTransition_INTERFACE_DEFINED__

/* interface ISlideTransition */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISlideTransition;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("7F38E55D-78CA-4434-B975-7506841A4A6C")
    ISlideTransition : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetID( 
            /* [retval][out] */ LONG *lID) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetName( 
            /* [retval][out] */ BSTR *pName) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetDescription( 
            /* [retval][out] */ BSTR *pDescription) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetFilename( 
            /* [retval][out] */ BSTR *pFilename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DoEffect( 
            /* [in] */ ISlideImage *pPicC,
            /* [in] */ ISlideImage *pPicA,
            /* [in] */ ISlideImage *pPicB,
            /* [in] */ LONG lPercent,
            /* [in] */ LONGLONG lParam) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISlideTransitionVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISlideTransition * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISlideTransition * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISlideTransition * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISlideTransition * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISlideTransition * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISlideTransition * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISlideTransition * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetID )( 
            ISlideTransition * This,
            /* [retval][out] */ LONG *lID);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetName )( 
            ISlideTransition * This,
            /* [retval][out] */ BSTR *pName);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetDescription )( 
            ISlideTransition * This,
            /* [retval][out] */ BSTR *pDescription);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetFilename )( 
            ISlideTransition * This,
            /* [retval][out] */ BSTR *pFilename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *DoEffect )( 
            ISlideTransition * This,
            /* [in] */ ISlideImage *pPicC,
            /* [in] */ ISlideImage *pPicA,
            /* [in] */ ISlideImage *pPicB,
            /* [in] */ LONG lPercent,
            /* [in] */ LONGLONG lParam);
        
        END_INTERFACE
    } ISlideTransitionVtbl;

    interface ISlideTransition
    {
        CONST_VTBL struct ISlideTransitionVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISlideTransition_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISlideTransition_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISlideTransition_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISlideTransition_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISlideTransition_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISlideTransition_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISlideTransition_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISlideTransition_GetID(This,lID)	\
    (This)->lpVtbl -> GetID(This,lID)

#define ISlideTransition_GetName(This,pName)	\
    (This)->lpVtbl -> GetName(This,pName)

#define ISlideTransition_GetDescription(This,pDescription)	\
    (This)->lpVtbl -> GetDescription(This,pDescription)

#define ISlideTransition_GetFilename(This,pFilename)	\
    (This)->lpVtbl -> GetFilename(This,pFilename)

#define ISlideTransition_DoEffect(This,pPicC,pPicA,pPicB,lPercent,lParam)	\
    (This)->lpVtbl -> DoEffect(This,pPicC,pPicA,pPicB,lPercent,lParam)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideTransition_GetID_Proxy( 
    ISlideTransition * This,
    /* [retval][out] */ LONG *lID);


void __RPC_STUB ISlideTransition_GetID_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideTransition_GetName_Proxy( 
    ISlideTransition * This,
    /* [retval][out] */ BSTR *pName);


void __RPC_STUB ISlideTransition_GetName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideTransition_GetDescription_Proxy( 
    ISlideTransition * This,
    /* [retval][out] */ BSTR *pDescription);


void __RPC_STUB ISlideTransition_GetDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideTransition_GetFilename_Proxy( 
    ISlideTransition * This,
    /* [retval][out] */ BSTR *pFilename);


void __RPC_STUB ISlideTransition_GetFilename_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideTransition_DoEffect_Proxy( 
    ISlideTransition * This,
    /* [in] */ ISlideImage *pPicC,
    /* [in] */ ISlideImage *pPicA,
    /* [in] */ ISlideImage *pPicB,
    /* [in] */ LONG lPercent,
    /* [in] */ LONGLONG lParam);


void __RPC_STUB ISlideTransition_DoEffect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISlideTransition_INTERFACE_DEFINED__ */


#ifndef __ISlideFactory_INTERFACE_DEFINED__
#define __ISlideFactory_INTERFACE_DEFINED__

/* interface ISlideFactory */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ISlideFactory;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("04196464-735C-4F51-AFE0-0CA39F9D225D")
    ISlideFactory : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetEffectDir( 
            /* [in] */ BSTR Dir) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetTransitionDir( 
            /* [in] */ BSTR Dir) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetEffectCount( 
            /* [retval][out] */ LONG *lCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetEffectName( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetEffectDescription( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Description) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetEffectPlugInFileName( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateEffect( 
            /* [in] */ LONG lID,
            /* [in] */ LONGLONG lParam,
            /* [retval][out] */ ISlideEffect **pEffect) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTransitionCount( 
            /* [retval][out] */ LONG *lCount) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTransitionName( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Name) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTransitionDescription( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Description) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetTransitionPlugInFileName( 
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateTransition( 
            /* [in] */ LONG lID,
            /* [in] */ LONGLONG lParam,
            /* [retval][out] */ ISlideTransition **pTransition) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ISlideFactoryVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE *QueryInterface )( 
            ISlideFactory * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void **ppvObject);
        
        ULONG ( STDMETHODCALLTYPE *AddRef )( 
            ISlideFactory * This);
        
        ULONG ( STDMETHODCALLTYPE *Release )( 
            ISlideFactory * This);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfoCount )( 
            ISlideFactory * This,
            /* [out] */ UINT *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetTypeInfo )( 
            ISlideFactory * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo **ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE *GetIDsOfNames )( 
            ISlideFactory * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE *Invoke )( 
            ISlideFactory * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS *pDispParams,
            /* [out] */ VARIANT *pVarResult,
            /* [out] */ EXCEPINFO *pExcepInfo,
            /* [out] */ UINT *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetEffectDir )( 
            ISlideFactory * This,
            /* [in] */ BSTR Dir);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *SetTransitionDir )( 
            ISlideFactory * This,
            /* [in] */ BSTR Dir);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetEffectCount )( 
            ISlideFactory * This,
            /* [retval][out] */ LONG *lCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetEffectName )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Name);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetEffectDescription )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Description);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetEffectPlugInFileName )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CreateEffect )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [in] */ LONGLONG lParam,
            /* [retval][out] */ ISlideEffect **pEffect);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetTransitionCount )( 
            ISlideFactory * This,
            /* [retval][out] */ LONG *lCount);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetTransitionName )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Name);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetTransitionDescription )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Description);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *GetTransitionPlugInFileName )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [retval][out] */ BSTR *Filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE *CreateTransition )( 
            ISlideFactory * This,
            /* [in] */ LONG lID,
            /* [in] */ LONGLONG lParam,
            /* [retval][out] */ ISlideTransition **pTransition);
        
        END_INTERFACE
    } ISlideFactoryVtbl;

    interface ISlideFactory
    {
        CONST_VTBL struct ISlideFactoryVtbl *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ISlideFactory_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ISlideFactory_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ISlideFactory_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ISlideFactory_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ISlideFactory_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ISlideFactory_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ISlideFactory_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ISlideFactory_SetEffectDir(This,Dir)	\
    (This)->lpVtbl -> SetEffectDir(This,Dir)

#define ISlideFactory_SetTransitionDir(This,Dir)	\
    (This)->lpVtbl -> SetTransitionDir(This,Dir)

#define ISlideFactory_GetEffectCount(This,lCount)	\
    (This)->lpVtbl -> GetEffectCount(This,lCount)

#define ISlideFactory_GetEffectName(This,lID,Name)	\
    (This)->lpVtbl -> GetEffectName(This,lID,Name)

#define ISlideFactory_GetEffectDescription(This,lID,Description)	\
    (This)->lpVtbl -> GetEffectDescription(This,lID,Description)

#define ISlideFactory_GetEffectPlugInFileName(This,lID,Filename)	\
    (This)->lpVtbl -> GetEffectPlugInFileName(This,lID,Filename)

#define ISlideFactory_CreateEffect(This,lID,lParam,pEffect)	\
    (This)->lpVtbl -> CreateEffect(This,lID,lParam,pEffect)

#define ISlideFactory_GetTransitionCount(This,lCount)	\
    (This)->lpVtbl -> GetTransitionCount(This,lCount)

#define ISlideFactory_GetTransitionName(This,lID,Name)	\
    (This)->lpVtbl -> GetTransitionName(This,lID,Name)

#define ISlideFactory_GetTransitionDescription(This,lID,Description)	\
    (This)->lpVtbl -> GetTransitionDescription(This,lID,Description)

#define ISlideFactory_GetTransitionPlugInFileName(This,lID,Filename)	\
    (This)->lpVtbl -> GetTransitionPlugInFileName(This,lID,Filename)

#define ISlideFactory_CreateTransition(This,lID,lParam,pTransition)	\
    (This)->lpVtbl -> CreateTransition(This,lID,lParam,pTransition)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_SetEffectDir_Proxy( 
    ISlideFactory * This,
    /* [in] */ BSTR Dir);


void __RPC_STUB ISlideFactory_SetEffectDir_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_SetTransitionDir_Proxy( 
    ISlideFactory * This,
    /* [in] */ BSTR Dir);


void __RPC_STUB ISlideFactory_SetTransitionDir_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetEffectCount_Proxy( 
    ISlideFactory * This,
    /* [retval][out] */ LONG *lCount);


void __RPC_STUB ISlideFactory_GetEffectCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetEffectName_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Name);


void __RPC_STUB ISlideFactory_GetEffectName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetEffectDescription_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Description);


void __RPC_STUB ISlideFactory_GetEffectDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetEffectPlugInFileName_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Filename);


void __RPC_STUB ISlideFactory_GetEffectPlugInFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_CreateEffect_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [in] */ LONGLONG lParam,
    /* [retval][out] */ ISlideEffect **pEffect);


void __RPC_STUB ISlideFactory_CreateEffect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetTransitionCount_Proxy( 
    ISlideFactory * This,
    /* [retval][out] */ LONG *lCount);


void __RPC_STUB ISlideFactory_GetTransitionCount_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetTransitionName_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Name);


void __RPC_STUB ISlideFactory_GetTransitionName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetTransitionDescription_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Description);


void __RPC_STUB ISlideFactory_GetTransitionDescription_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_GetTransitionPlugInFileName_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [retval][out] */ BSTR *Filename);


void __RPC_STUB ISlideFactory_GetTransitionPlugInFileName_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ISlideFactory_CreateTransition_Proxy( 
    ISlideFactory * This,
    /* [in] */ LONG lID,
    /* [in] */ LONGLONG lParam,
    /* [retval][out] */ ISlideTransition **pTransition);


void __RPC_STUB ISlideFactory_CreateTransition_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ISlideFactory_INTERFACE_DEFINED__ */



#ifndef __SlidePL_LIBRARY_DEFINED__
#define __SlidePL_LIBRARY_DEFINED__

/* library SlidePL */
/* [helpstring][uuid][version] */ 


EXTERN_C const IID LIBID_SlidePL;

EXTERN_C const CLSID CLSID_CSlideImage;

#ifdef __cplusplus

class DECLSPEC_UUID("1AE93581-D93B-460F-A5C8-ACB84EFDEEFF")
CSlideImage;
#endif

EXTERN_C const CLSID CLSID_CSlideEffect;

#ifdef __cplusplus

class DECLSPEC_UUID("94292858-FA59-4A84-91E9-5ECEA03DAAFC")
CSlideEffect;
#endif

EXTERN_C const CLSID CLSID_CSlideTransition;

#ifdef __cplusplus

class DECLSPEC_UUID("10949562-C891-4275-8311-67B453BD97D5")
CSlideTransition;
#endif

EXTERN_C const CLSID CLSID_CSlideFactory;

#ifdef __cplusplus

class DECLSPEC_UUID("ADD76CEB-4B19-4E92-928E-46AD0846755F")
CSlideFactory;
#endif
#endif /* __SlidePL_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long *, unsigned long            , BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserMarshal(  unsigned long *, unsigned char *, BSTR * ); 
unsigned char * __RPC_USER  BSTR_UserUnmarshal(unsigned long *, unsigned char *, BSTR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long *, BSTR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


